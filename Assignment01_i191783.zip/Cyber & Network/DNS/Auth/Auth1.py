import socket
import json
import time

myIp = '127.0.0.1'
myPort = 53014

TIMETOLIVE = 1

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((myIp, myPort))

print('Root DNS Listening At {}'.format(sock.getsockname()))

def loadData(filename):
    data = ""
    with open(filename, 'r') as file:
        data = file.read()
    data = json.loads(data)
    #print(data)
    print("data fetched")
    return data



def createResponse(query):
    data = loadData("/home/badar/Desktop/Assignments/Cyber & Network/DNS/Auth/authData1.json")
    query = json.loads(query)
    records = []
    for i in data:
        record = {
            "name": i["DOMAIN"],
            "value": i["IP"] ,
            "type": "A",
            "ttl": 1
                  }
        if record["name"] == query["Domain"]:
            records.append(record)
    response = {
        "TransactionID": query["TransactionID"],
        "Records": records        
                }
    return json.dumps(response)
    print(json.loads(json.dumps(response)))


while True:
    
    query, client = sock.recvfrom(512)
    print("Request:\n", query.decode('utf-8'), "\nFrom: ", client, "\n")
    result = createResponse(query.decode('utf-8'))
    time.sleep(1)
    sock.sendto(str(result).encode('utf-8'), client)


print('Connection Closed')
sock.close()