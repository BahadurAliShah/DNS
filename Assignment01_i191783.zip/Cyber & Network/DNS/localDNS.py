from random import randint
import re
import socket
import json

myIp = '127.0.0.1'
myPort = 53000

rootServers = [
    ('127.0.0.1', 53005),
    ('127.0.0.1', 53006),
    ('127.0.0.1', 53007),
    ('127.0.0.1', 53008),
    ('127.0.0.1', 53009)
]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((myIp, myPort))

print('Local DNS Listening At {}'.format(sock.getsockname()))

def findDNSquery(query, browser):
    
    print('Received from client {} : {}'.format(browser, query))

    query = query.decode('utf-8')
    query = json.loads(query)
    if checkCache(query["Domain"]):
        print("Cache Found")
        return json.dumps({
            "name": query["Domain"],
            "value":checkCache(query["Domain"]),
            "type": "A",
            "ttl": "1",
            "TransactionID": query["TransactionID"]
        })
    
    #find in cache
    print("Cache Not Found")
    result = sendToAuth(sendToTLD(sendToRoot(query), query), query)
    if result == None:
        return "Not Found"
    result["TransactionID"]=query["TransactionID"]
    updateCache(query["Domain"], result["value"])
    return json.dumps(result)





def sendToAuth(Records, firstQuery):
    print(Records)
    if Records == None:
        print("None Auth")
        return None
    relatedTLD = Records[0]
    tID = randomFunc()
    queryToTLD = {
        "TransactionID": tID,
        "Domain": firstQuery["Domain"]
    }
    queryToTLD = json.dumps(queryToTLD).encode('utf-8')

    dest = (relatedTLD["value"].split(":")[0].encode('utf-8'), int(relatedTLD["value"].split(":")[1]))
    sock.sendto(queryToTLD, dest);
    
    response = {}
    responseID = ""
    while responseID != tID:
        response, server = sock.recvfrom(1024)
        response = json.loads(response.decode('utf-8'))
        # print(response, "kldfkldffffffffff")
        # print(response["TransactionID"])
        responseID = response["TransactionID"]
        
    print("\n\n")

    for i in response['Records']:
        print(i)
        
    print("response returned by ", server)
    return response["Records"][0]






def sendToTLD(Records, firstQuery):
    relatedTLD = None
    for i in Records:
        if i["name"] == "."+firstQuery["Domain"].split(".")[-1]:
            print("matched")
            relatedTLD = i
            break;
        else:
            print("not")
    if relatedTLD == None:
        return None
    tID = randomFunc()
    queryToTLD = {
        "TransactionID": tID,
        "Domain": firstQuery["Domain"]
    }
    queryToTLD = json.dumps(queryToTLD).encode('utf-8')

    dest = (relatedTLD["value"].split(":")[0].encode('utf-8'), int(relatedTLD["value"].split(":")[1]))
    sock.sendto(queryToTLD, dest);
    
    response = {}
    responseID = ""
    while responseID != tID:
        response, server = sock.recvfrom(1024)
        response = json.loads(response.decode('utf-8'))
        # print(response, "kldfkldffffffffff")
        # print(response["TransactionID"])
        responseID = response["TransactionID"]
        
    print("\n\n")

    for i in response['Records']:
        print(i)
        
    print("response returned by ", server)
    return response["Records"]








def sendToRoot(query):
    tID = randomFunc()
    queryToRoot = {
        "TransactionID": tID,
        "Domain": query["Domain"]
    }
    queryToRoot = json.dumps(queryToRoot).encode('utf-8')
    for i in rootServers:
        sock.sendto(queryToRoot, i)
    
    response = {}
    responseID = ""
    while responseID != tID:
        response, server = sock.recvfrom(1024)
        response = json.loads(response.decode('utf-8'))
        # print(response, "kldfkldffffffffff")
        # print(response["TransactionID"])
        responseID = response["TransactionID"]
        
    print("\n\n")
    for i in response['Records']:
        print(i)
        
    print("response returned by ", server)
    return response["Records"]
    
    




def checkCache(web):
    data = ""
    with open ("/home/badar/Desktop/Assignments/Cyber & Network/DNS/localDNSCache.json") as file:
        data = (file.read())

    if len(data)>0:
        data = json.loads(data)
        for i in data:
            if data[i]["domain"] == web:
                return data[i]["ip"]
        return False
    else:
        return False
    
def updateCache(domain, ip):
    newRec = {"domain": domain, "ip": ip}
    with open ("/home/badar/Desktop/Assignments/Cyber & Network/DNS/localDNSCache.json") as file:
        data = (file.read())
        data.replace("\'", "\"")
    if len(data)>0:
        data = json.loads(data)
        for i in data:
            if data[i]["domain"] == domain:
                data[i]["ip"] = ip
        data[len(data)] = newRec
        with open ("/home/badar/Desktop/Assignments/Cyber & Network/DNS/localDNSCache.json", "w") as file:
            data = json.dumps(data)
            file.write(data)
    else:
        #newRec = json.dumps()
        with open ("/home/badar/Desktop/Assignments/Cyber & Network/DNS/localDNSCache.json", "w") as file:
            data = json.dumps({0:newRec})
            file.write(data)



def randomFunc():
    #return str(hex(randint(0, 0xFFFFFFFFFFFF)))
    return str(hex(0xFFFFFFFFFFFF))



while True:
    query, browser = sock.recvfrom(2048)
    
    result = findDNSquery(query, browser)
    
    
    
    sock.sendto(result.encode(), browser)


print('Connection Closed')
sock.close()