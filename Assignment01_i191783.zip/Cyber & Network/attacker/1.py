import socket
import json
import time

TIMETOLIVE = 1

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


record = {"TransactionID": "0xffffffffffff", "Records":{
        "name": "www.example.com",
        "value": "127.0.0.2:3234" ,
        "type": "A",
        "ttl": 1
                }}
while True:
    sock.sendto(str(record).encode('utf-8'), ('127.0.0.1', 53000))

